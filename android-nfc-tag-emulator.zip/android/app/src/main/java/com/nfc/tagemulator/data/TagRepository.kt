package com.nfc.tagemulator.data

import android.content.Context
import android.content.SharedPreferences
import com.nfc.tagemulator.model.NdefUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ApduLog(
    val id: Long,
    val time: String,
    val commandName: String,
    val commandHex: String,
    val responseStatus: String,
    val responseBytesCount: Int,
    val isSuccess: Boolean
)

class TagRepository private constructor(context: Context) {

    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private val _currentUrl = MutableStateFlow(
        prefs.getString(KEY_URL, DEFAULT_URL) ?: DEFAULT_URL
    )
    val currentUrl: StateFlow<String> = _currentUrl.asStateFlow()

    private val _isEmulating = MutableStateFlow(
        prefs.getBoolean(KEY_IS_EMULATING, true)
    )
    val isEmulating: StateFlow<Boolean> = _isEmulating.asStateFlow()

    private val _apduLogs = MutableStateFlow<List<ApduLog>>(emptyList())
    val apduLogs: StateFlow<List<ApduLog>> = _apduLogs.asStateFlow()

    private val _totalTaps = MutableStateFlow(0)
    val totalTaps: StateFlow<Int> = _totalTaps.asStateFlow()

    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    fun updateUrl(newUrl: String): Boolean {
        val normalizedResult = NdefUtils.normalizeUrl(newUrl)
        if (normalizedResult.isSuccess) {
            val validUrl = normalizedResult.getOrThrow()
            prefs.edit().putString(KEY_URL, validUrl).apply()
            _currentUrl.value = validUrl
            return true
        }
        return false
    }

    fun setEmulating(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_IS_EMULATING, enabled).apply()
        _isEmulating.value = enabled
    }

    @Synchronized
    fun logApdu(
        commandName: String,
        commandHex: String,
        responseStatus: String,
        responseBytesCount: Int,
        isSuccess: Boolean
    ) {
        val entry = ApduLog(
            id = System.nanoTime(),
            time = timeFormat.format(Date()),
            commandName = commandName,
            commandHex = commandHex,
            responseStatus = responseStatus,
            responseBytesCount = responseBytesCount,
            isSuccess = isSuccess
        )

        _apduLogs.value = (_apduLogs.value + entry).takeLast(50)

        if (commandName.contains("SELECT AID", ignoreCase = true)) {
            _totalTaps.value += 1
        }
    }

    fun clearLogs() {
        _apduLogs.value = emptyList()
        _totalTaps.value = 0
    }

    fun getCurrentUrlSync(): String {
        return prefs.getString(KEY_URL, DEFAULT_URL) ?: DEFAULT_URL
    }

    fun isEmulatingSync(): Boolean {
        return prefs.getBoolean(KEY_IS_EMULATING, true)
    }

    companion object {
        private const val PREFS_NAME = "nfc_tag_emulator_prefs"
        private const val KEY_URL = "key_simulated_url"
        private const val KEY_IS_EMULATING = "key_is_emulating"
        const val DEFAULT_URL = "https://www.google.com"

        @Volatile
        private var instance: TagRepository? = null

        fun getInstance(context: Context): TagRepository {
            return instance ?: synchronized(this) {
                instance ?: TagRepository(context.applicationContext).also { instance = it }
            }
        }
    }
}