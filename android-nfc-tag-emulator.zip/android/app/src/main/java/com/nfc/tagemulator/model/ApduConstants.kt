package com.nfc.tagemulator.model

object ApduConstants {
    val AID_NDEF_TYPE4: ByteArray = byteArrayOf(
        0xD2.toByte(), 0x76.toByte(), 0x00.toByte(), 0x00.toByte(),
        0x85.toByte(), 0x01.toByte(), 0x01.toByte()
    )

    val FILE_ID_CC: ByteArray = byteArrayOf(0xE1.toByte(), 0x03.toByte())
    val FILE_ID_NDEF: ByteArray = byteArrayOf(0xE1.toByte(), 0x04.toByte())

    const val CLA_ISO7816: Byte = 0x00.toByte()
    const val INS_SELECT: Byte = 0xA4.toByte()
    const val INS_READ_BINARY: Byte = 0xB0.toByte()

    const val P1_SELECT_BY_NAME: Byte = 0x04.toByte()
    const val P1_SELECT_BY_ID: Byte = 0x00.toByte()

    val STATUS_SUCCESS: ByteArray = byteArrayOf(0x90.toByte(), 0x00.toByte())
    val STATUS_FILE_NOT_FOUND: ByteArray = byteArrayOf(0x6A.toByte(), 0x82.toByte())
    val STATUS_WRONG_PARAMS: ByteArray = byteArrayOf(0x6B.toByte(), 0x00.toByte())
    val STATUS_WRONG_LENGTH: ByteArray = byteArrayOf(0x67.toByte(), 0x00.toByte())
    val STATUS_INS_NOT_SUPPORTED: ByteArray = byteArrayOf(0x6D.toByte(), 0x00.toByte())
    val STATUS_CLA_NOT_SUPPORTED: ByteArray = byteArrayOf(0x6E.toByte(), 0x00.toByte())

    fun ByteArray.toHexString(): String {
        return joinToString(" ") { "%02X".format(it) }
    }
}