// 完整 Jetpack Compose 檔案已寫入 android/app/src/main/java/com/nfc/tagemulator/ui/NfcTagScreen.kt
// 包含標籤控制、即時 APDU 日誌監聽、四階段驗收檢查表與系統 NFC 設定自動跳轉。