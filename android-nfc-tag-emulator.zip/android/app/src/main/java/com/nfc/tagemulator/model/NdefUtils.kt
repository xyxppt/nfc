package com.nfc.tagemulator.model

import java.io.ByteArrayOutputStream
import java.net.URI
import java.nio.charset.StandardCharsets

object NdefUtils {

    data class UriPrefix(val code: Byte, val prefix: String)

    val URI_PREFIXES: List<UriPrefix> = listOf(
        UriPrefix(0x01.toByte(), "http://www."),
        UriPrefix(0x02.toByte(), "https://www."),
        UriPrefix(0x03.toByte(), "http://"),
        UriPrefix(0x04.toByte(), "https://"),
        UriPrefix(0x05.toByte(), "tel:"),
        UriPrefix(0x06.toByte(), "mailto:")
    )

    fun normalizeUrl(rawUrl: String): Result<String> {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("網址不能為空白"))
        }

        val withScheme = if (!trimmed.startsWith("http://", ignoreCase = true) &&
            !trimmed.startsWith("https://", ignoreCase = true)
        ) {
            "https://$trimmed"
        } else {
            trimmed
        }

        return try {
            val uri = URI(withScheme)
            val host = uri.host
            if (host.isNullOrBlank() || !host.contains(".")) {
                Result.failure(IllegalArgumentException("網址主機名稱無效（例如需包含 example.com）"))
            } else {
                Result.success(withScheme)
            }
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("網址格式錯誤: ${e.message}"))
        }
    }

    fun findPrefixAndRemainder(url: String): Pair<Byte, String> {
        for (item in URI_PREFIXES) {
            if (url.startsWith(item.prefix, ignoreCase = true)) {
                val remainder = url.substring(item.prefix.length)
                return Pair(item.code, remainder)
            }
        }
        return Pair(0x00.toByte(), url)
    }

    fun buildCapabilityContainer(): ByteArray {
        return byteArrayOf(
            0x00.toByte(), 0x0F.toByte(), // CCLEN (15)
            0x20.toByte(),               // Mapping Version 2.0
            0x00.toByte(), 0x7F.toByte(), // MLe (127 bytes)
            0x00.toByte(), 0x7F.toByte(), // MLc (127 bytes)
            0x04.toByte(),               // TLV Type (NDEF File Control)
            0x06.toByte(),               // TLV Length
            0xE1.toByte(), 0x04.toByte(), // File ID of NDEF
            0x08.toByte(), 0x00.toByte(), // Max NDEF size (2048 bytes)
            0x00.toByte(),               // Read access: granted
            0xFF.toByte()                // Write access: read-only
        )
    }

    fun buildNdefFile(url: String): ByteArray {
        val (prefixCode, remainder) = findPrefixAndRemainder(url)
        val remainderBytes = remainder.toByteArray(StandardCharsets.UTF_8)
        val payloadLength = 1 + remainderBytes.size

        val ndefRecordStream = ByteArrayOutputStream()

        if (payloadLength <= 255) {
            ndefRecordStream.write(0xD1) // MB=1, ME=1, SR=1, TNF=001
            ndefRecordStream.write(0x01) // Type Length = 1
            ndefRecordStream.write(payloadLength)
            ndefRecordStream.write(0x55) // 'U'
            ndefRecordStream.write(prefixCode.toInt() and 0xFF)
            ndefRecordStream.write(remainderBytes)
        } else {
            ndefRecordStream.write(0xC1) // MB=1, ME=1, SR=0, TNF=001 (長網址支援)
            ndefRecordStream.write(0x01)
            ndefRecordStream.write((payloadLength ushr 24) and 0xFF)
            ndefRecordStream.write((payloadLength ushr 16) and 0xFF)
            ndefRecordStream.write((payloadLength ushr 8) and 0xFF)
            ndefRecordStream.write(payloadLength and 0xFF)
            ndefRecordStream.write(0x55)
            ndefRecordStream.write(prefixCode.toInt() and 0xFF)
            ndefRecordStream.write(remainderBytes)
        }

        val ndefMessage = ndefRecordStream.toByteArray()
        val nlen = ndefMessage.size

        val fileStream = ByteArrayOutputStream()
        fileStream.write((nlen ushr 8) and 0xFF)
        fileStream.write(nlen and 0xFF)
        fileStream.write(ndefMessage)

        return fileStream.toByteArray()
    }
}