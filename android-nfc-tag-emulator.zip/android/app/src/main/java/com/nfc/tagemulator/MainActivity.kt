package com.nfc.tagemulator

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.nfc.tagemulator.ui.NfcTagScreen
import com.nfc.tagemulator.ui.NfcViewModel
import com.nfc.tagemulator.ui.theme.NfcTagEmulatorTheme

class MainActivity : ComponentActivity() {

    private val viewModel: NfcViewModel by viewModels()
    private var nfcAdapter: NfcAdapter? = null

    private val nfcStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (NfcAdapter.ACTION_ADAPTER_STATE_CHANGED == intent?.action) {
                checkAndUpdateNfcStatus()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        checkAndUpdateNfcStatus()

        registerReceiver(
            nfcStateReceiver,
            IntentFilter(NfcAdapter.ACTION_ADAPTER_STATE_CHANGED)
        )

        setContent {
            NfcTagEmulatorTheme {
                NfcTagScreen(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkAndUpdateNfcStatus()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(nfcStateReceiver)
        } catch (_: Exception) {}
    }

    private fun checkAndUpdateNfcStatus() {
        val adapter = nfcAdapter ?: NfcAdapter.getDefaultAdapter(this)
        nfcAdapter = adapter
        viewModel.setNfcStatus(
            supported = adapter != null,
            enabled = adapter?.isEnabled == true
        )
    }
}