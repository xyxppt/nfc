package com.nfc.tagemulator.service

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import android.util.Log
import com.nfc.tagemulator.data.TagRepository
import com.nfc.tagemulator.model.ApduConstants
import com.nfc.tagemulator.model.ApduConstants.toHexString
import com.nfc.tagemulator.model.NdefUtils
import java.util.Arrays

class NfcHceService : HostApduService() {

    private enum class SelectedFile {
        NONE,
        CAPABILITY_CONTAINER,
        NDEF_DATA
    }

    private var currentFile = SelectedFile.NONE
    private var isAppSelected = false

    private val repository by lazy {
        TagRepository.getInstance(applicationContext)
    }

    override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        if (commandApdu == null || commandApdu.size < 4) {
            logExchange("INVALID_APDU", commandApdu ?: byteArrayOf(), ApduConstants.STATUS_WRONG_LENGTH, 0, false)
            return ApduConstants.STATUS_WRONG_LENGTH
        }

        if (!repository.isEmulatingSync()) {
            logExchange("EMULATION_DISABLED", commandApdu, ApduConstants.STATUS_FILE_NOT_FOUND, 0, false)
            return ApduConstants.STATUS_FILE_NOT_FOUND
        }

        val cla = commandApdu[0]
        val ins = commandApdu[1]
        val p1 = commandApdu[2]
        val p2 = commandApdu[3]

        if (cla != ApduConstants.CLA_ISO7816) {
            logExchange("UNSUPPORTED_CLA", commandApdu, ApduConstants.STATUS_CLA_NOT_SUPPORTED, 0, false)
            return ApduConstants.STATUS_CLA_NOT_SUPPORTED
        }

        return when (ins) {
            ApduConstants.INS_SELECT -> handleSelect(commandApdu, p1, p2)
            ApduConstants.INS_READ_BINARY -> handleReadBinary(commandApdu, p1, p2)
            else -> {
                logExchange("UNSUPPORTED_INS", commandApdu, ApduConstants.STATUS_INS_NOT_SUPPORTED, 0, false)
                ApduConstants.STATUS_INS_NOT_SUPPORTED
            }
        }
    }

    private fun handleSelect(commandApdu: ByteArray, p1: Byte, p2: Byte): ByteArray {
        if (commandApdu.size < 5) {
            logExchange("SELECT_INVALID_LENGTH", commandApdu, ApduConstants.STATUS_WRONG_LENGTH, 0, false)
            return ApduConstants.STATUS_WRONG_LENGTH
        }

        val lc = commandApdu[4].toInt() and 0xFF
        val dataOffset = 5
        if (commandApdu.size < dataOffset + lc) {
            logExchange("SELECT_TRUNCATED", commandApdu, ApduConstants.STATUS_WRONG_LENGTH, 0, false)
            return ApduConstants.STATUS_WRONG_LENGTH
        }

        val data = commandApdu.copyOfRange(dataOffset, dataOffset + lc)

        if (p1 == ApduConstants.P1_SELECT_BY_NAME) {
            return if (Arrays.equals(data, ApduConstants.AID_NDEF_TYPE4)) {
                isAppSelected = true
                currentFile = SelectedFile.NONE
                logExchange("SELECT AID: Type 4 NDEF App", commandApdu, ApduConstants.STATUS_SUCCESS, 2, true)
                ApduConstants.STATUS_SUCCESS
            } else {
                isAppSelected = false
                currentFile = SelectedFile.NONE
                logExchange("SELECT AID: Unknown (${data.toHexString()})", commandApdu, ApduConstants.STATUS_FILE_NOT_FOUND, 2, false)
                ApduConstants.STATUS_FILE_NOT_FOUND
            }
        }

        if (p1 == ApduConstants.P1_SELECT_BY_ID) {
            return when {
                Arrays.equals(data, ApduConstants.FILE_ID_CC) -> {
                    currentFile = SelectedFile.CAPABILITY_CONTAINER
                    logExchange("SELECT File: CC (E1 03)", commandApdu, ApduConstants.STATUS_SUCCESS, 2, true)
                    ApduConstants.STATUS_SUCCESS
                }
                Arrays.equals(data, ApduConstants.FILE_ID_NDEF) -> {
                    currentFile = SelectedFile.NDEF_DATA
                    logExchange("SELECT File: NDEF (E1 04)", commandApdu, ApduConstants.STATUS_SUCCESS, 2, true)
                    ApduConstants.STATUS_SUCCESS
                }
                else -> {
                    currentFile = SelectedFile.NONE
                    logExchange("SELECT File: Unknown (${data.toHexString()})", commandApdu, ApduConstants.STATUS_FILE_NOT_FOUND, 2, false)
                    ApduConstants.STATUS_FILE_NOT_FOUND
                }
            }
        }

        logExchange("SELECT: Invalid P1 ($p1)", commandApdu, ApduConstants.STATUS_WRONG_PARAMS, 2, false)
        return ApduConstants.STATUS_WRONG_PARAMS
    }

    private fun handleReadBinary(commandApdu: ByteArray, p1: Byte, p2: Byte): ByteArray {
        val fileData: ByteArray = when (currentFile) {
            SelectedFile.CAPABILITY_CONTAINER -> NdefUtils.buildCapabilityContainer()
            SelectedFile.NDEF_DATA -> {
                val currentUrl = repository.getCurrentUrlSync()
                NdefUtils.buildNdefFile(currentUrl)
            }
            SelectedFile.NONE -> {
                logExchange("READ BINARY: No File Selected", commandApdu, ApduConstants.STATUS_FILE_NOT_FOUND, 2, false)
                return ApduConstants.STATUS_FILE_NOT_FOUND
            }
        }

        val offset = ((p1.toInt() and 0xFF) shl 8) or (p2.toInt() and 0xFF)

        if (offset >= fileData.size) {
            logExchange("READ BINARY: Offset Out of Range ($offset >= ${fileData.size})", commandApdu, ApduConstants.STATUS_WRONG_PARAMS, 2, false)
            return ApduConstants.STATUS_WRONG_PARAMS
        }

        val requestedLength = if (commandApdu.size >= 5) {
            val le = commandApdu[4].toInt() and 0xFF
            if (le == 0) 256 else le
        } else {
            fileData.size - offset
        }

        val availableLength = fileData.size - offset
        val actualLength = minOf(requestedLength, availableLength)

        val responsePayload = fileData.copyOfRange(offset, offset + actualLength)
        val fullResponse = responsePayload + ApduConstants.STATUS_SUCCESS

        logExchange(
            "READ BINARY: ${currentFile.name} (off=$offset, len=$actualLength/${fileData.size})",
            commandApdu,
            ApduConstants.STATUS_SUCCESS,
            fullResponse.size,
            true
        )

        return fullResponse
    }

    override fun onDeactivated(reason: Int) {
        isAppSelected = false
        currentFile = SelectedFile.NONE
    }

    private fun logExchange(
        commandName: String,
        commandApdu: ByteArray,
        statusBytes: ByteArray,
        responseBytesCount: Int,
        isSuccess: Boolean
    ) {
        val cmdHex = commandApdu.toHexString()
        val statusHex = statusBytes.toHexString()
        repository.logApdu(commandName, cmdHex, statusHex, responseBytesCount, isSuccess)
    }
}